module.exports = {
  trailingSlash: true,
  images: {
    unoptimized: true
  }
}